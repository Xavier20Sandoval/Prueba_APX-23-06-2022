package com.bbva.mneo.batch;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

import com.bbva.mneo.dto.customers.CustomersDTO;

public class CustomerFieldSetMapper implements FieldSetMapper<CustomersDTO>{

	
	@Override
	public CustomersDTO mapFieldSet(FieldSet fieldSet) throws BindException {
		// TODO Auto-generated method stub
		//Mapeamos los elementos 
		CustomersDTO custmer = new CustomersDTO();
		
		custmer.setCustomerId(fieldSet.readInt("id"));
		custmer.setCustomerName(fieldSet.readString("nombre"));
		custmer.setAddress(fieldSet.readString("direccion"));
		custmer.setCity(fieldSet.readString("ciudad"));
		custmer.setState(fieldSet.readString("estado"));
		custmer.setZipCode(fieldSet.readString("cp"));
		
		
		return custmer;
	}

}
