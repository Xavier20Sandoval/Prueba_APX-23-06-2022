package com.bbva.mneo.batch;

import java.util.List;

import org.slf4j.Logger;
import org.springframework.batch.item.ItemWriter;

import com.bbva.mneo.dto.customers.CustomersDTO;
import com.bbva.mneo.lib.r001.MNEOR001;

public class WriterCustomer implements ItemWriter<CustomersDTO>{
	
	private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(WriterCustomer.class);
			
	MNEOR001 mneoR001;//Aqui se hace una inyeccion de la interfaz 
	

	@Override
	public void write(List<? extends CustomersDTO> listCustomer) throws Exception {
		// TODO Auto-generated method stub
		LOGGER.info("Entrando a wrtiterCustomer");
		for (CustomersDTO customersDTO : listCustomer) {
		mneoR001.executeInsert(customersDTO);
		}
		
	}
	public MNEOR001 getMneoR001() {
		return mneoR001;
	}

	public void setMneoR001(MNEOR001 mneoR001) {
		this.mneoR001 = mneoR001;
	}

}
