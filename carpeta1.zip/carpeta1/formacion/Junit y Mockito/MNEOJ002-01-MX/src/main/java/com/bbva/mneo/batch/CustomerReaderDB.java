package com.bbva.mneo.batch;

import java.util.List;

import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;

import com.bbva.mneo.dto.customers.CustomersDTO;
import com.bbva.mneo.lib.r001.MNEOR001;

public class CustomerReaderDB implements ItemReader<List<CustomersDTO>> {

	MNEOR001 mneoR001;
	private int pageIndex=1;
	private int pageSize=2;
	
	public MNEOR001 getMneoR001() {
		return mneoR001;
	}

	public void setMneoR001(MNEOR001 mneoR001) {
		this.mneoR001 = mneoR001;
	}

	@Override
	public List<CustomersDTO>read()
			throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
		// TODO Auto-generated method stub
		
		//Hacemos la lectura de todos los elemetos de la bd
		//Hacemos una con una paginacion
		//Logica para crear el metodo
		
		List<CustomersDTO> listCustomer = null;
		listCustomer=mneoR001.executeGetListCustomer(pageSize, pageIndex);//Lo guardamos en la lista
		pageIndex+=pageSize;//hacemos el control de pageindex1,3,5
		
		if(listCustomer == null || listCustomer.isEmpty()) {
			//Aqui detenemos nuestra lectura
			return null;
		}
		
		return listCustomer;//Le regresamos la lista
	}
	
	
}
