package com.bbva.mpbd.dto.employees;



import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * The EmployeesDTO class...
 */
public class PruebaDTO implements Serializable  {
	private static final long serialVersionUID = 2931699728946643245L;

	/* Attributes section for the DTO */

	/**
	 * The name attribute
	 */
private int idBeneficiario;
	private String NameBeneficiario;
	private float monto;
	private String DescripcionMov;
	
	
	

	public int getIdBeneficiario() {
		return idBeneficiario;
	}

	public void setIdBeneficiario(int idBeneficiario) {
		this.idBeneficiario = idBeneficiario;
	}

	public String getNameBeneficiario() {
		return NameBeneficiario;
	}

	public void setNameBeneficiario(String nameBeneficiario) {
		NameBeneficiario = nameBeneficiario;
	}

	public float getMonto() {
		return monto;
	}

	public void setMonto(float monto) {
		this.monto = monto;
	}

	public String getDescripcionMov() {
		return DescripcionMov;
	}

	public void setDescripcionMov(String descripcionMov) {
		DescripcionMov = descripcionMov;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * Indicates whether some other object is "equal to" this one.
	 */
	@Override
	public boolean equals(final Object obj) {
		if (obj == null) { return false; }
		if (obj == this) { return true; }
		if (obj.getClass() != getClass()) {
			return false;
		}
		final PruebaDTO rhs = (PruebaDTO) obj;
		return new EqualsBuilder().appendSuper(super.equals(obj))
					.append(idBeneficiario, rhs.idBeneficiario)
					.append(NameBeneficiario, rhs.NameBeneficiario)
					.append(monto, rhs.monto)
					.append(DescripcionMov, rhs.DescripcionMov)
					.isEquals();
	}

	/**
	 * Returns a hash code value for the object.
	 */
	@Override
	public int hashCode() {
		return new HashCodeBuilder()
			.append(this.idBeneficiario)
			.append(this.NameBeneficiario)
			.append(this.monto)
			.append(this.DescripcionMov)
			.toHashCode();
	}

	/**
	 * Returns a string representation of the object.
	 * It is important to OBFUSCATE the attributes that are sensitive to show in the representation.
	 */
	@Override
	public String toString() {
		return new ToStringBuilder(this)
			.append("idBeneficiario", idBeneficiario)
			.append("NameBeneficiario", NameBeneficiario)
			.append("monto", monto)
			.append("DescripcionMov", DescripcionMov)
			.toString();
	}
}
