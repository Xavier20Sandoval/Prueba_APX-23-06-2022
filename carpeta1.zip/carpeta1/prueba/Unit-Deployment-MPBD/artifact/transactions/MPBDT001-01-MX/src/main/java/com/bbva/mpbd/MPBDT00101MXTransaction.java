package com.bbva.mpbd;

import com.bbva.elara.domain.transaction.Advice;
import com.bbva.elara.domain.transaction.Severity;
import com.bbva.mpbd.dto.employees.PruebaDTO;
import com.bbva.mpbd.lib.r001.MPBDR001;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * com.bbva.mpbd:MPBDR001:bundle:0.1.0-SNAPSHOT
 * Transaccion Employees
 *
 */
public class MPBDT00101MXTransaction extends AbstractMPBDT00101MXTransaction {

	private static final Logger LOGGER = LoggerFactory.getLogger(MPBDT00101MXTransaction.class);

	/**
	 * The execute method...
	 */
	
	@Override
	public void execute() {
		MPBDR001 mpbdR001 = this.getServiceLibrary(MPBDR001.class);
		// TODO - Implementation of business logic
		String entrada = this.getEntrada();
		if("0".equals(entrada)) {
		LOGGER.info("Entre a la operacion de ");
		PruebaDTO employees = mpbdR001.executeInsert(getEmployeesin());
		setEmployeesout(employees);
		LOGGER.info("Saliendo de la operacion insertar");
		}
		else if("1".equals(entrada)){
			LOGGER.info("Entra a la operacion de eliminar");
			mpbdR001.executeDeleteById(getEmployeesin());
			LOGGER.info("Saliendo de la operacion actualizar");
		}
		else if("2".equals(entrada)) {
			LOGGER.info("Entra a la operacion actualizar");
			PruebaDTO employees = mpbdR001.executeUpdateById(getEmployeesin());
			setEmployeesout(employees);
			LOGGER.info("Saliendo de la operacion actualizar");
		}
		else if("3".equals(entrada)) {
			LOGGER.info("Entra a la operacion consultar por name");
			PruebaDTO employees =mpbdR001.executeGetByName(getEmployeesin());
			setEmployeesout(employees);
			LOGGER.info("Saliendo de la operacion consultar por name");
		}
		else if("4".equals(entrada)) {
			LOGGER.info("Entre a la operacion de consulta de todos employees ");
			List<PruebaDTO> lista= mpbdR001.executeGetAll();
			setLista(lista);
			LOGGER.info("Saliendo de la operación de consulta de todos employees");
		}
		
		
		Advice advice = getAdvice();
		if(advice !=null && "MNEO01317007".equals(advice.getCode())) {
			setSeverity(Severity.EWR);
		}else {
			setSeverity(Severity.OK);
			LOGGER.info("La operacion termino de manera Exitosa");
		}
	}

}
