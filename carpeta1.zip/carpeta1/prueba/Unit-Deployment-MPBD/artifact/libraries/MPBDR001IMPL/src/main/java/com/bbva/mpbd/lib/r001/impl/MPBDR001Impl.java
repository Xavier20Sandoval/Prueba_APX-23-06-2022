package com.bbva.mpbd.lib.r001.impl;



import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bbva.apx.exception.db.DuplicateKeyException;
import com.bbva.apx.exception.db.NoResultException;
import com.bbva.apx.exception.db.TimeoutException;
import com.bbva.mpbd.dto.employees.PruebaDTO;

/**
 * The MPBDR001Impl class...
 */
public class MPBDR001Impl extends MPBDR001Abstract {

	private static final Logger LOGGER = LoggerFactory.getLogger(MPBDR001Impl.class);

	/**
	 * The execute method...
	 */
	@Override
	public PruebaDTO executeInsert(PruebaDTO employees) {
		// TODO Auto-generated method stub

		int result = 0;
		
		
			try {

				result = this.jdbcUtils.update("insert", employees.getIdBeneficiario(), employees.getNameBeneficiario()
						, employees.getDescripcionMov());

			} catch (DuplicateKeyException e) {
				LOGGER.error("ocurrio un problema se duplico el key en la tabla de customer");
				addAdvice("MPBD01317004");
				// TODO: handle exception
			} catch (TimeoutException e) {
				LOGGER.error("ocurrio un problema se excedio el tiempo para insertar en la tabla customers");
				addAdvice("MPBD01317005");
				// TODO: handle exception
			}
			LOGGER.info("El resultado del insert es {}", result);

		
		return employees;

	}

	

	@Override
	public PruebaDTO executeUpdateById(PruebaDTO employees) {
		// TODO Auto-generated method stub
		LOGGER.info("Entrando al metodo executeUpdate");

		int result = 0;
		try {
			Map<String, Object> params = new HashMap<>();

			params.put("employeeId", employees.getIdBeneficiario());
			params.put("employeeName", employees.getNameBeneficiario());
			params.put("employeeMov", employees.getDescripcionMov());
			result = this.jdbcUtils.update("updateEmployeesName", params);

		} catch (DuplicateKeyException e) {
			LOGGER.error("ocurrio un problema se duplico el key en la tabla de customer");
			addAdvice("MPBD01317004");
			// TODO: handle exception
		} catch (TimeoutException e) {
			LOGGER.error("ocurrio un problema se excedio el tiempo para insertar en la tabla customers");
			addAdvice("MPBD01317005");
			// TODO: handle exception
		}
		LOGGER.info("El resultado del upate es {}", result);
		return employees;

	}

	@Override
	public PruebaDTO executeGetByName(PruebaDTO employees) {
		// TODO Auto-generated method stub
		LOGGER.info("Entrando al metodo executeGetByName");
		PruebaDTO empleado = new PruebaDTO();
		
		try {
			
			Map<String, Object> params = new HashMap<>();
			params.put("employeeId", employees.getIdBeneficiario());
			List<Map<String, Object>> lista = new ArrayList<Map<String, Object>>();
			lista = this.jdbcUtils.queryForList("getEmployees", params);
			
			LOGGER.info("Tamlista="+lista.size());
			
			if (lista.size() > 1)
			{
				LOGGER.info("Entrando a buscar el registro");
				for (Map<String, Object> map : lista) {
					if (empleado.equals(map.get("NAME_BENEFICIARIO").toString())) {
						empleado.setIdBeneficiario(Integer.parseInt(map.get("employeeId").toString()));
						empleado.setNameBeneficiario(map.get("employeeName").toString());
						empleado.setDescripcionMov(map.get("employeeMov").toString());
						break;
					}

				}
				LOGGER.info("Saliendo del if encontrar registros");
			} else {
				LOGGER.info("Entrando al else");
				
				empleado.setIdBeneficiario(Integer.parseInt(lista.get(0).get("employeeId").toString()));
				empleado.setNameBeneficiario(lista.get(0).get("employeeName").toString());
				empleado.setDescripcionMov(lista.get(0).get("employeeMov").toString());
			}
			LOGGER.info("Saliendo del else");

		} catch (NoResultException e) {
			LOGGER.error("Ocurrio un problema al obtener el customer DB");
			addAdvice("MPBD1317008");
		}
		LOGGER.info("Saliendo del metodo executeGetByName");
		return empleado;
	}
	public List<PruebaDTO> executeGetAll() {
		// TODO Auto-generated method stub

		List<PruebaDTO> lista2 = new LinkedList<PruebaDTO>();
		List<Map<String,Object>> lista= new ArrayList<Map<String,Object>>(); 
		lista=this.jdbcUtils.queryForList("getEmployeesAll");
		
		for(Map<String,Object> map: lista ) {
				PruebaDTO cliente= new PruebaDTO();	
				cliente.setIdBeneficiario(Integer.parseInt(map.get("employeeId").toString()));
				cliente.setNameBeneficiario(map.get("employeeName").toString());
				cliente.setDescripcionMov(map.get("employeeMov").toString());
				
				lista2.add(cliente);
		}
		
		return lista2;
	}

	@Override
	public void execute() {
		// TODO - Implementation of business logic
	}



	@Override
	public void executeDeleteById(PruebaDTO employess) {
		// TODO Auto-generated method stub
		LOGGER.info("Entrando al metodo executeDeleteById");

		int result = 0;
		try {
			Map<String, Object> params = new HashMap<>();
			params.put("employeeId", employess.getIdBeneficiario());
			result = this.jdbcUtils.update("deleteStatus", params);
		} catch (TimeoutException e) {
			LOGGER.error("Ocurrio un problema se excedio el tiempo para actializar las tablas customers ");
			addAdvice("MPBD1317005");
		}
		LOGGER.info("El resultado de delete es: ", result);
		
	}
}