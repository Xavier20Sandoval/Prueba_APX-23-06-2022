package com.bbva.mpbd.lib.r001;

import java.util.List;

import com.bbva.mpbd.dto.employees.PruebaDTO;

/**
 * The  interface MPBDR001 class...
 */
public interface MPBDR001 {

	
	public PruebaDTO executeInsert (PruebaDTO employees);
	public void executeDeleteById(PruebaDTO employess);
	public PruebaDTO executeUpdateById(PruebaDTO employees);
	public PruebaDTO executeGetByName(PruebaDTO employees);
	public List<PruebaDTO> executeGetAll();
	
	
	
	void execute();

}
